#Thomas King, ETGG1801-01, lab05

diameter = input("Enter the diameter of the sphere (in m): ")
density = input("Enter the density of the sphere (in kg/cubic-m): ")
depth = input("Enter the depth of the crust layer: ")
#insert string = int(insert string)     permenantly changes to integer  
diameter = int(diameter)
density = int(density)
depth = int(depth)
#formula for volume: volume = 4/3 (Pie)radius ** 3
#formula for mass of an object is: mass = volume * density
radius = diameter / 2
volume = 4/3 * 3.14 * radius ** 3
mass = volume * density
#setting mass to round will set the number of decimal places and round up to the set amount
rmass = round(mass, 2)
#print(radius)
#print(rmass)
print("The mass of the crust is", rmass)

chp = input("\nEnter the current hp: ")
mhp = input("Enter the maximum hp: ")
chp = int(chp)
mhp = int(mhp)
#fix this so there aren't spaces and set hard cap of - to 40
print("/","-"*8,"\\")
#finish the health bar and calculations