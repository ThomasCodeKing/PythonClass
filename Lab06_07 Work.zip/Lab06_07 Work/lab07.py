#Thomas King, ETGG1801-01, lab07
#Note to self
#4 types of shapes, make an image, 
import pygame
import time

pygame.init()   #sets up some other sub-modules, allocates memory
window_dimentions = (800, 600)
window = pygame.display.set_mode(window_dimentions)     #creates window with a set value. Possibly usefull for randint windows
#shapes will apear in order from top to bottom
rect_color_black = (0, 0, 0)
rect_color_white = (255, 255, 255)

pygame.draw.rect(window, rect_color_white, (49, 49, 100,100))
#                window, (color), (x-coordinate, y-coordinate, width, height)
pygame.draw.rect(window, rect_color_black, (149, 49, 100,100))     #Top row
pygame.draw.rect(window, rect_color_white, (249, 49, 100,100)) 
pygame.draw.rect(window, rect_color_black, (349, 49, 100,100)) 
pygame.draw.rect(window, rect_color_white, (449, 49, 100,100)) 
pygame.draw.rect(window, rect_color_black, (549, 49, 100,100)) 
pygame.draw.rect(window, rect_color_white, (649, 49, 100,100)) 
pygame.draw.rect(window, rect_color_black, (749, 49, 100,100)) 

pygame.draw.rect(window, rect_color_black, (49, 149, 100,100))      #Second row
pygame.draw.rect(window, rect_color_white, (149, 149, 100,100)) 
pygame.draw.rect(window, rect_color_black, (249, 149, 100,100)) 
pygame.draw.rect(window, rect_color_white, (349, 149, 100,100)) 
pygame.draw.rect(window, rect_color_black, (449, 149, 100,100)) 
pygame.draw.rect(window, rect_color_white, (549, 149, 100,100)) 
pygame.draw.rect(window, rect_color_black, (649, 149, 100,100)) 

pygame.draw.rect(window, (104, 104, 104), (400, 549, 850,400))      #floor

pygame.draw.arc(window, (255, 0, 0), rect, 45, 90, width=3)         #walls?


pygame.draw.circle(window, (59, 252, 72), (400, 300), 15)

pygame.display.flip()
time.sleep(3)
pygame.quit()