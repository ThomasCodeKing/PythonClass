# pygame_intro01_widnow.pygame_intro01_widnow.py
import pygame
import time
#do this before any other pygame code
pygame.init()       #sets up some other sub-modules, allocates memory

window_dimentions = (800, 600)
window = pygame.display.set_mode(window_dimentions)     #creates a window

circle_color = (255, 255, 0) #red, green, blue
pygame.draw.circle(window, circle_color, (400, 300), 50)      #window is pygame


rect_area = (350, 250, 25, 400)
#  x-coordinate, y-coordinate, width, height
pygame.draw.rect(window, (255, 0, 0), rect_area)
#surface: anything we draw to it will show on the pygame window


pygame.display.flip()    #tells pygame that the back-buffer is now ready to become the front bufffer and visible

time.sleep(3)

#do this when you're done with your program
pygame.quit()       #closes winddow and stops any music

