width = input("Enter a width in meters: ")     #width is a string
height = input("Enter a height in meters: ")    #width is a string
#area = int(width) * int(height)     #temporarily changes the value of width from a string to an int
#width = int(width)     #this is permenant
#height = int(height)   #this is permenant
area 
area = width * height

print("you entered width = ", width,"and height = ", height)
print ("area is ", area)
