#when finding file I can type: cd PythonClassWork\Module4
#then to run file type "python" then the file name to run; Example: python Notes.py 
#Another way is to highlight file location and then type cmd

#examples of using excape sequences
#   \n Newline
#   \t Tab
#   \" Print a quote (don't end a string)
#   \'Print a single-quote
#   \\ Print a single backslash

s = "asdf"
s = 'asdf'
s = """asdf"""
s = '''asdf'''

print("I said 'Hello' .")
print ("""I said "Hello".""")
print(""" first line here
scond line here""")

print("ccc", "ddd", end="@")    #end will make the line below it print on the same row: the default is \n
print("eee", "fff")
#variables
width = 10
print(instance(width, int))     #true
print(instance(width, float))   #false
print(instance(width, str))     #false
print(instance(width, bool))    #false
print (width is None)           #false, but different? How? idk
#operators
print(5 // 2) #=2 // rounds down 
print(5 % 2)    #The remainder (modulo) of dividing a number
print(9 % 10) 
print("Hello, Monkai" * 3)  #drepeats the string when using *
print((4 + 7) * 5 **2)    #PEMDAS Works!!
x += 1 #adds 1 to x value and replaces the old value  (augmented  assignment operator)
#functions
width = input("Enter a width in meters: ")     #width is a string
height = input("Enter a height in meters: ")    #width is a string
#area = int(width) * int(height)     #temporarily changes the value of width from a string to an int
#width = int(width)     #this is permenant
#height = int(height)   #this is permenant
area 
area = width * height

print("you entered width = ", width,"and height = ", height)
print ("area is ", area)

print("/","-"*40, "\\",sep = "")

