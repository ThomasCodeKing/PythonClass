print ("Hello, Monkai")
print (3 * 7)
3 * 7
x = 42 
print(x)
print(x / 2)
x = x / 2 
print(x)

radius = 9.7
area = 3.14 * radius ** 2
print("The area of a", radius * 2, "diameter circle is", area)
print("The area of a", radius * 2, "diameter circle is", area, sep="@@")
print("The area of a", radius * 2, "diameter circle is", area, sep="")

input("Pres enter to continue")

#to find this file you will enter: PythonClassWork\First_Script.py