#Thomas King, ETGG1801-01, lab03

#Feel free to edit this to ones own needs
fname = "Fang"
lname = "Chong"
age = 109
minutes = 14400
rate = 50
opposite = 36
adjacent = 48

#Logic to make program run: Do not edit this
kdistance = minutes / 60 * rate
#Note to self: kdistance = 12000       debugging note  
seconds = minutes * 60
#Note to self: seconds = 864000     debugging note 
verticle = opposite / 12 
horizontal = adjacent / 12
xhypotenuse = verticle ** 2 + horizontal ** 2
yhypotenuse = xhypotenuse **  .5        #Thank you whoever in the discord reminded me I can .5 instead of square root. 

#Output
print("My name is", fname, lname, "and I am", age, "years old.")

print("My name is", fname, lname, "and I am", age, "years old.", sep="...")

print("The vehicle travelled", kdistance, "kilometers in", seconds, "seconds at a rate of", rate, "kph.")

print("The hypotenuse of a triangle is", yhypotenuse, "feet if the opposite side is", verticle, "feet and the adjacent side is", horizontal, "feet.")

input("Press Enter to quit...")


#I used the items below to help me with debugging 
#print(rate)
#print(opposite)
#print(adjacent)
#print(kdistance)
#print(verticle)
#print(horizontal)
#print(xhypotenuse)
#print(yhypotenuse)
#Note to self: to find this file you will enter: PythonClassWork\Module3\Section1\lab03.py