# droplet.py: contains a class called Droplet that represents info
#    about a SINGLE droplet
import random
import pygame

DROPLET_RADIUS = 5

class Droplet:
    """ A bluish circle thing that drops due to gravity """
    def __init__(self, new_x, new_y):
        self.position = [new_x, new_y]     # a position VECTOR
        self.velocity = [0, 0]           # a velocity VECTOR (horizontal speed,
                                           #     vertical speed), in px/s
        #self.radius = 5     # use DROPLET_RADIUS since I want all droplets
                             # to be the same size.
        self.color = (random.randint(100, 200), random.randint(100, 255), 255)

    def update(self, delta_time, max_y):
        # Acceleration is a change in velocity
        #   velocity_x += accel_x * delta_time
        # Gravity produces an acceleration.  We can simulate it like this:
        #   velocity_y += gravity_accel * delta_time
        self.velocity[1] += 200 * delta_time

        self.position[0] += self.velocity[0] * delta_time
        self.position[1] += self.velocity[1] * delta_time

        # If we've moved off-screen, return True, otherwise return False
        return self.position[1] > max_y + DROPLET_RADIUS

    def draw(self, surf):
        pygame.draw.circle(surf, self.color, self.position, DROPLET_RADIUS)
        pygame.draw.circle(surf, (255,255,255), self.position, DROPLET_RADIUS, 1)

    def __str__(self):
        return "a Droplet"


# A little "trick" -- __name__ is a variable that holds the name
#   of the module (droplet) if this file is imported from another
#   file; or "__main__" if we're running THIS file.  A handy way
#   to test this file's contents, but only if we're running this file
if __name__ == "__main__":
    pygame.display.init()
    pygame.font.init()

    # All of these are objects!
    win = pygame.display.set_mode((800, 600))
    clock = pygame.time.Clock()
    font = pygame.font.SysFont("Courier New", 16)

    done = False

    # Make a test droplet instance
    D = Droplet(400, 10)
    # Droplet is the name of the class from above
    # D is being passed for the self arg to the constructor
    # 400 and 10 are the new_x and new_y arguments to the constructor
    print("D =", D)  # Test the __str__ method
    D_dead = False

    while not done:
        # UPDATE
        dt = clock.tick() / 1000
        if not D_dead:
            D_dead = D.update(dt, win.get_height())
        # print(result)

        # INPUT
        evt = pygame.event.poll()  # evt is an object
        if evt.type == pygame.QUIT:
            done = True
        if evt.type == pygame.KEYDOWN and evt.key == pygame.K_ESCAPE:
            done = True

        # DRAWING
        win.fill((0, 0, 0))
        if not D_dead:
            D.draw(win)
        pygame.display.flip()

    pygame.quit()
