import pygame
import raincloud

pygame.display.init()
pygame.font.init()

# All of these are objects!
win = pygame.display.set_mode((800, 600))
clock = pygame.time.Clock()
font = pygame.font.SysFont("Courier New", 16)

done = False

# Make a test droplet instance
R = raincloud.Raincloud(400, 10, 100, 20, win.get_width(), win.get_height())
                                    # raincloud is the name of the module
                                    # Raincloud is the name of the class in that module
                                    # R is being passed for the self arg to the constructor
                                    # 400 and 10 are the new_x and new_y arguments to the constructor
                                    # 100 and 20 are the width and height
                                    # The window width and height are the last arguments.
print("R =", R)        # Test the __str__ method

print(dir(R))
print(R.get_num_droplets.__doc__)

#R.set_emission_rate(-100)
R.set_emission_rate(100)

while not done:
    # UPDATE
    dt = clock.tick() / 1000
    R.update(dt)

    # INPUT
    evt = pygame.event.poll()   # evt is an object
    if evt.type == pygame.QUIT:
        done = True
    if evt.type == pygame.KEYDOWN and evt.key == pygame.K_ESCAPE:
        done = True

    # DRAWING
    win.fill((0, 0, 0))
    R.draw(win)
    text_to_draw = "# Droplets: " + str(R.get_num_droplets())
    text_surf = font.render(text_to_draw, False, (0,0,0), (255,255,255))
    win.blit(text_surf, (0, 550))
    pygame.display.flip()

pygame.quit()
