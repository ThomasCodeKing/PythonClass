# The raincloud is a grey rectangle that bounces off the
# left/right side of the screen, spawning and managing droplets
# as it goes
import pygame
import random
import droplet

class Raincloud:
    def __init__(self, new_x, new_y, width, height, win_width, win_height):
        # Note: this and droplet share some names, but they
        # are completely separate.  If we're here, we're talking about
        # the raincloud's position; if we're in droplet.py, we're talking
        # about a droplet's position.
        self.position = [new_x, new_y]                  # The upper-left corner of the raincloud
        self.horizontal_speed = -100       # px/s
        self.size = (width, height)
        self.window_size = (win_width, win_height)

        # The most interesting part!!
        self.emission_rate = 50      # Number of particles to spawn PER SECOND
        self.num_particles_to_spawn = 0   # This is a fractional amount.  Ex.
                                          #   2.45 that means to spawn 2 particles
                                          # and that we're 45% of the way to spawning
                                          # a thrid.  After, we spawn the 2 particles
                                          # (in update), we'll sub that from 2.45
        self.droplet_list = []

    def update(self, delta_time):
        # Spawn new droplets according to the emission rate
        self.num_particles_to_spawn += self.emission_rate * delta_time
        new_spawns = int(self.num_particles_to_spawn)
        self.num_particles_to_spawn -= new_spawns
        for i in range(new_spawns):
            self.spawn_droplet()

        # Move and bounce the raincloud itself
        self.position[0] += self.horizontal_speed * delta_time
        if self.position[0] < 0:
            # We went PAST the left edge of the screen
            self.position[0] = 0        # Make us just touch the left edge
            self.horizontal_speed *= -1
        if self.position[0] + self.size[0] > self.window_size[0]:
            # We went PAST the right edge of the screen
            self.position[0] = self.window_size[0] - self.size[0]
            self.horizontal_speed *= -1

        # Move all active droplets (new and old) -- remove any "dead" droplets
        for cur_droplet in self.droplet_list:
            # Remember that the droplet's update method returns True if this thing
            # should be destroyed -- we just need to pay attention to it!
            #cur_droplet.update(delta_time, self.window_size[1])
            if cur_droplet.update(delta_time, self.window_size[1]):
                self.droplet_list.remove(cur_droplet)

    def draw(self, surf):
        # Draw the raincloud itself
        pygame.draw.rect(surf, (64, 64, 64), (self.position[0], self.position[1], self.size[0], self.size[1]))

        # Draw the active droplets
        for d in self.droplet_list:
            # d is a Droplet object
            d.draw(surf)

    def spawn_droplet(self):
        # Spawn one new droplet
        new_Dx = random.randint(int(self.position[0]), int(self.position[0] + self.size[0]))
        new_Dy = self.position[1] + self.size[1] + droplet.DROPLET_RADIUS
        new_D = droplet.Droplet(new_Dx, new_Dy)
        self.droplet_list.append(new_D)

    def get_num_droplets(self):
        """ Gets the number of droplets in action now"""
        return len(self.droplet_list)

    def set_emission_rate(self, new_rate):
        if new_rate < 0 or new_rate > 5000:
            raise ValueError("Emission rate must be between 0 and 5000")
        else:
            self.emission_rate = new_rate


