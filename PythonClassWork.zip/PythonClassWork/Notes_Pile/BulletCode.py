"""
bullet_x_list = []
bullet_y_list = []
bullet_h_speed = []
bullet_v_speed = []
enemy_list = []
#game loop

    #updates
    #hit detection for enemies
    #one bullet, one enemy = one distance check
    # five bullet, one enemy = five distance check
    #one bullet, six enemy = six distance checks
    #three bullet, 4 enemy = twelve distance checks
    #must do a while loop or and index- based for loop
    for i in range(len(bullet_x_list)-1, -1, -1):
        #we look write and code here to use i to index the bullet list
        #bullet needs to check all enemies
        for cur_enemy in enemy_list:
            #here I need to check bullet with cur enemy
        dist = #bullet_x_list[i]
        if dist < bullet_radius + enemy_radius
            #they touch
            #kill the enemy
            #kill the bullet
            del bullet_x_list[i]
            del bullet_y_list[i]
            del bullet_h_speed[i]
            del bullet_v_speed[i]
            enemy_list.remove(cur_enemy)
            #we dont want to do anything else with the dead enemy or bullet

#example of player invulnerability timer
player =  [x = 400, y = 300,
invul_timer = 0.00, #tiemr in seconds vtill the player takes damage again
flicker_timer = 0.0 #flip every 0.1 seconds
invul_draw = True]

#in game loop
    #UPDATES
    if player["invul_timer"] > 0:
        player["invul_timer"] -= delta_time
        player["flicker_timer"] -= delta_time
        if player["flicker_timer"] <= 0:
            #change draw style
            player["invul_draw"] = not player["invul_draw"]
            player["flicker_timer"] += 0.1
    # look for this between player hits and enemies
"""