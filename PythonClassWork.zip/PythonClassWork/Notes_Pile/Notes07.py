import random
import pygame
import time
import math

pygame.display.init()
win_width = 800
win_height = 600
win = pygame.display.set_mode((win_width,win_height))
"""
#if statements with a while statement

npc_num = random.randint(1,100)
guesses_remaining = 10
player_num = None
while guesses_remaining > 0 and player_num != npc_num:
    player_num = int(input(f"[guesses remaining {guesses_remaining}]Enter a number (1-10): "))

    #print(npc_num == player_num)
    if npc_num == player_num:
        print("Nice Job!")
    elif npc_num > player_num:
        print("Too low!")
        guesses_remaining -= 1
    else:
        print("Too high!")
        guesses_remaining -= 1
print(f"NPC guessed: {npc_num}")
"""

#fixed_while: itereates a fixed number of times
#load assets before the loop
Cacodemon_sprite = pygame.image.load("Cacodemon_sprite64.png")

print("about to start...")
num_cacodemon = 1690
#i = 4
i = 0
start_time = time.time()
while i < num_cacodemon :   #1690
    #want i to repeat
    #print(f"i = {i}")
    x = random.randint(0, win_width)
    y = random.randint(0,win_height)
    red = random.randint(100,255)
    green = random.randint(100,255)
    blue = random.randint(100,255)
    radius = random.randint(2,5)
    rotation = random.randint(0,60)
    scale = random.uniform(0.25,0.75)
    scaled_cacodemon_width = scale * Cacodemon_sprite.get_width()
    scaled_cacodemon_height = scale * Cacodemon_sprite.get_height()
    scaled_cacodemon = pygame.transform.scale(Cacodemon_sprite, (scaled_cacodemon_width,scaled_cacodemon_height))
    rotated_cacodemon = pygame.transform.rotate(scaled_cacodemon, rotation)
    win.blit(rotated_cacodemon, (x - rotated_cacodemon.get_width() / 2, rotated_cacodemon.get_height() / 2))
    #win.blit(scaled_cacodemon, (x - scaled_cacodemon_width / 2, scaled_cacodemon_height / 2))
    #win.blit(Cacodemon_sprite, (x - Cacodemon_sprite.get_width() / 2, y - Cacodemon_sprite.get_height() / 2))
    #pygame.draw.circle(win, (red,green,blue), (x,y), radius)
    
    i += 1
print("done")

end_time = time.time()
print(f"time passed {end_time - start_time}")


pygame.display.flip()
time.sleep(3)
pygame.quit
