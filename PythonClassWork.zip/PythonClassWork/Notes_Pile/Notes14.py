
class Person:
    """This is a docstring.
    Describe your class"""
    #this is a method: function associated with some class
    def talk(self, message):
        """docstring for methods
        describe parameters, return values, other notes"""
        print(self, "says", message)
    def identify(self):
        print("Hi, I'm", self.name, "and I'm", self.age, "years old")
    #this is a constructor method. an example of a Dunder (double underscore __)
    #methods in python. all Dunders are called by python
    #this method is called right after a new instance of class
    def __init__(self, new_name):
        #usally make attributes here
        print("A new Person is born")
        self.age = 0
        self.name = new_name

    #whenever we need to convert a Person into a string like a print statement
    def __str__(self):
        #return print statement used for debugging
        return f"<Person name={self.name} age= {self.age}>"

#main program
a = Person("ben")    #instantiate the Person class and store in a
b = Person("Gene")    #another instance b
#use the constructor to initialize our attributes
#a.name = "bob"
#a.age = 24
b.age = 43
#b.name = "Rogg"
#we dont have to pass an argument for self
#we do for any other parameters like message


a.talk("Heretic!")        #calling the method through a
b.talk("Traitor!")        #calling the method through b
print("a = ", a)
print("b = ", b)
a.identify()
b.identify()
