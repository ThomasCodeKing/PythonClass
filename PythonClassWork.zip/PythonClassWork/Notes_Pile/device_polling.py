import pygame

pygame.display.init()
win_width = 800
win_height = 600
win = pygame.display.set_mode((win_width, win_height))

game_over = False
rect_x = 400
rect_y = 300
rect_size = 10

#game loop
while game_over == False:
    #updates

    #input
    #when doing only device polling need to call pygame.event.poll() once but you dont need to
    #save the result to an event variable.
    pygame.event.poll()

    #keyboard state
    keys_pressed = pygame.key.get_pressed()
    if keys_pressed[pygame.K_ESCAPE]:
        game_over = True
    elif keys_pressed[pygame.K_LEFT]:
        #rect_x -= 10
        rect_x -= 0.1
    elif keys_pressed[pygame.K_RIGHT]:
        #rect_x += 10
        rect_x += 0.1
    print(f"keys pressed = {keys_pressed}")

    #mouse state
    mouse_x, mouse_y = pygame.mouse.get_pos()
    print(f"mouse is at({mouse_x}, {mouse_y})")

    mouse_buttons = pygame.mouse.get_pressed()
    print(f"mouse buttons: {mouse_buttons}")

    #mouse_buttons[0] is Boolean: is the left-mouse button down?
    #mouse_buttons[1] is Boolean: is the middle-mouse button down?
    #mouse_buttons[2] is Boolean: is the right-mouse button down?
    if mouse_buttons[0]:
        print("The user is left-clicking")

    #drawing
    win.fill((32, 50, 32))
    # draw
    pygame.draw.rect(win, (0, 255, 0), (rect_x - rect_size / 2, rect_y - rect_size / 2, rect_size, rect_size))
    pygame.display.flip()
