#Thomas King Notes for Module12
#each time the user click the mouse then they spawn a new circle
#store information in a list of dictionaries

#pygame setup
import pygame
import random

pygame.display.init()
pygame.font.init()
win_width = 800
win_height = 600
win = pygame.display.set_mode((win_width, win_height))
clock = pygame.time.Clock()
font_obj = pygame.font.SysFont("Courier New", 18)
done = False

#list of dictionaries
#circle_lists will be a 4 element lists: 0=x, 1=y, 2=radius, 3=speed
#CIRCLE_X_INDEX = 0
#IRCLE_Y_INDEX = 1
#CIRCLE_RADIUS = 2
#CIRCLE_SPEED = 3
circle_lists = []

#circle_x_lists = []
#circle_y_lists = []
#circle_radius_list = []
#circle_speed_list = []
#red = random.randint(0,255) \ green = random.randint(0,255) \ blue = random.randint(0,255) \ circle_color = (red, green, blue)
#circle_color = (random.randint(0, 255), random.randint(0,255), random.randint(0,255))
#Game Loop
while not done:
    #updates
    delta_time = clock.tick() / 1000
    #move circles in a for lop
    for cur_circle in circle_lists:
        #using a value based loop since circle_lists is a list of subdictionaries
        #4 element sublists. no need to go backwards

        cur_circle["x"] += cur_circle["speed"] * delta_time
        #destroy any that go off-screen
        #if you destroy the first or the second item the other elements collapse to take its place
        if cur_circle["x"] < -cur_circle["radius"] or \
            cur_circle["x"] > win_width + cur_circle["radius"]:
            circle_lists.remove(cur_circle)
    #input
    event = pygame.event.poll()
    if event.type == pygame.QUIT:
        done = True
    elif event.type == pygame.KEYDOWN:
        if event.key == pygame.K_ESCAPE:
            done = True
    elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:

    #drawing
    win.fill((0,0,0))
    #get at the circles by index

    i = 0
    while i < len(circle_lists):
        #i is the index into the list
        #index a sub-element of circle i.
        pygame.draw.circle(win, (circle_lists[i]["color"]), (circle_lists[i]["x"], circle_lists[i]["y"]), circle_lists[i]["radius"])
        i += 1

    text_surf = font_obj.render("# Circles: " + str(len(circle_lists)), False, (0,255,0))
    win.blit(text_surf, (0, 0))
    pygame.display.flip()

pygame.quit()
