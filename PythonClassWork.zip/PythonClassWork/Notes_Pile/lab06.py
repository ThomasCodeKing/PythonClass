import time
import random 
start_time = time.time()
print("x =",random.randint(1,10))
#alternative code 
#x = random.randint(1,10)
#print("x =",x)
y = (round(random.uniform(1.3, 2.1),  2))
#y = random.randomint(1.3, 2.1)
print("y = ", y)

degree = input("Enter degree to find radian: ")
degree = int(degree)
radian = (degree * 3.14) / 180
degree = float(degree)

print("The radian is...",radian)
end_time = time.time()
time = end_time - start_time
print(time)