# basic_sequences.py: illustrate some basic operations on tuples, strings, and list

# Creating a sequence of each type (note: a list can start empty and then have items added)
S = "This is a string"          # Make a STRING
T = (15, 3.1, "Bob")            # Make a (heterogeneous) TUPLE
L = [15, 3.1, "Bob"]            # Make a (heterogeneous) LIST

# Getting the number of elements using the len function
print(len(S))                   # 16
print(len(T))                   # 3
print(len(L))                   # 3

# A few new conversion functions
print(T)                        # (15, 3.1, "Bob")
T_as_a_list = list(T)
print(T_as_a_list)              # [15, 3.1, "Bob"]
L_as_a_tuple = tuple(L)
print(L_as_a_tuple)             # (15, 3.1, "Bob")

# Concatenation
S2 = S + "xyz"
print(S2)                       # This is a stringxyz
S3 = S + str(42)                # Still string concatenation (but converting an int to a string first)
print(S3)                       # This is a string42
T2 = T + (17, 18)
print(T2)                       # (15, 3.1, "Bob", 17, 18)
L2 = L + [99, 100]
print(L2)                       # [15, 3.1, "Bob", 99, 100]

# Repetition
print(S * 3)                    # This is a stringThis is a stringThis is a string
print(T * 3)                    # (15, 3.1, "Bob", 15, 3.1, "Bob", 15, 3.1, "Bob")
print(L * 2)                    # [15, 3.1, "Bob", 15, 3.1, "Bob"]

# The in operator tests for membership
print(3.1 in T)                 # True
print(4.2 in T)                 # False
if 3.1 in T:
    print("There is a 3.1 in T")
if 4.2 in T:
    print("There is a 4.2 in T")
print("h" in S)                 # True
print("x" in S)                 # False

# We'll resume at 10:10am (and do scheduling for <5m then resume sequence stuff)