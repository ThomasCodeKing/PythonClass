# chasey_ball2.py: just like chasey_ball, but we move the ball in such a way that all users should have roughly
# the same gameplay experience.
import pygame
import time
import random

# Pygame initialization
pygame.display.init()
pygame.font.init()
win_width = 800
win_height = 600
win = pygame.display.set_mode((win_width, win_height))

# Load assets
font_obj = pygame.font.SysFont("Courier New", 16)

# Create some variables
game_over = False
max_bounces = 10
num_bounces = 0       # how many bounces so far?
circle_x = 400
circle_y = 300
circle_radius = 50
# NEW: Instead of storing the pixels to change ON THIS MACHINE
# express our speeds as a rate
#circle_horizontal_speed = 0.5       # The pixels to move horizontally each frame
#circle_vertical_speed = 0.5        # The pixels to move vertically each frame
circle_speed = 200                  # The (positive) speed we move in either direction
circle_horizontal_rate = circle_speed       # How many pixels to move horizontally PER SECOND
circle_vertical_rate = circle_speed        # How many pixels to move vertically PER SECOND


target_teleport_delay = 2.0
target_x = random.randint(0, win_width)
target_y = random.randint(0, win_height)
target_teleport_time = time.time()

# New: record the time before we start the game loop
start_time = time.time()

# NEW: The big change to make our movement speed FRAME-RATE-INDEPENDENT
# is we need to express "stuff" in terms of RATES.  For example, we want
# the vertical and horizontal speed to be expressed in PIXELS / SECOND.
# Some other rates we might encounter:
#    ANIMATION_FRAMES / SECOND    (ex. 20 frames per second)
#    DEGREES / SECOND             (ex. 90 degrees per second)
#    PARTICLES / SECOND           (ex. spawn 100 particles per second)
# The way we compute the ACTUAL degrees to move THIS UPDATE, but make
# it adapt to frame-rate.  The answer comes from a high-school math formula:
#         DISTANCE = RATE * TIME
# Why does it work?  Say the fast machine just got a delta_time of 0.001
# and a slow machine getting a delta_time of 0.1.  When you multiply 200 (our rate)
# by 0.002 you would move 0.2 pixels on the fast machine and on the slow
# machine you move 20 pixels.

# A game loop
while not game_over:
    # @@@@@@@@@@@@@@@@@@
    # @ UPDATES        @
    # @@@@@@@@@@@@@@@@@@
    # ... NEW: calculate the time since the last update or since the game
    #     loop started (the first time we get to this section of code
    #     that's what we're measuring)
    delta_time = time.time() - start_time
    start_time = time.time()
    # ... see if enough time has passed to teleport the target
    if time.time() - target_teleport_time > target_teleport_delay:
        target_x = random.randint(0, win_width)
        target_y = random.randint(0, win_height)
        target_teleport_time = time.time()
    # ... move the circle
    # NEW: changing the old way to the new DISTANCE = RATE * TIME method
    #circle_x += circle_horizontal_speed
    #circle_y += circle_vertical_speed
    circle_x += circle_horizontal_rate * delta_time
    circle_y += circle_vertical_rate * delta_time

    # ... make it chase the target
    # ......see how we need to move horizontally
    if target_x > circle_x + 10:
        # The target is more than 10 pixels to the RIGHT of the circle -- move right
        #circle_horizontal_speed = 0.5
        circle_horizontal_rate = circle_speed
    elif target_x < circle_x - 10:
        # The target is more than 10 pixels to the LEFT of the circle -- move left
        #circle_horizontal_speed = -0.5
        circle_horizontal_rate = -circle_speed
    else:
        #circle_horizontal_speed = 0
        circle_horizontal_rate = 0
    # ......see how we need to move vertically
    if target_y > circle_y + 10:
        # The target is more than 10 pixels to the BOTTOM of the circle -- move down
        #circle_vertical_speed = 0.5
        circle_vertical_rate = circle_speed
    elif target_y < circle_y - 10:
        # The target is more than 10 pixels to the TOP of the circle -- move up
        #circle_vertical_speed = -0.5
        circle_vertical_rate = -circle_speed
    else:
        #circle_vertical_speed = 0
        circle_vertical_rate = 0

    # @@@@@@@@@@@@@@@@@@
    # @ INPUT          @
    # @@@@@@@@@@@@@@@@@@
    evt = pygame.event.poll()
    if evt.type == pygame.QUIT or \
            (evt.type == pygame.KEYDOWN and evt.key == pygame.K_ESCAPE):
        game_over = True

    # @@@@@@@@@@@@@@@@@@
    # @ DRAWING        @
    # @@@@@@@@@@@@@@@@@@
    # ...Erase the screen
    win.fill((64, 64, 64))

    # ... Draw some text showing the current bounce#
    text = f"Current Bounce: {num_bounces} / {max_bounces}"
    text_surf = font_obj.render(text, False, (255, 255, 0))
    win.blit(text_surf, (0, 0))

    # NEW: Draw the delta-time we're getting
    text = "Delta-Time: " + str(delta_time)
    text_surf = font_obj.render(text, False, (255, 255, 0))
    win.blit(text_surf, (400, 0))
    
    # ...Draw the ball
    pygame.draw.circle(win, (255, 0, 0), (circle_x, circle_y), circle_radius)

    # ... Draw the target
    pygame.draw.rect(win, (0, 255, 0), (target_x - 3, target_y - 3, 6, 6))

    # ... do the flip so we can see the new "frame" (generally done after you
    #       are finished drawing)
    pygame.display.flip()

    # This is to slow the game down to look right ON MY COMPUTER
    time.sleep(0.001)

# Pygame shutdown
pygame.quit()
