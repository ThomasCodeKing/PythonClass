import pygame
import time

pygame.display.init()
pygame.font.init()
win_width = 800
win_height = 600
win = pygame.display.set_mode((win_width, win_height))

font_obj = pygame.font.SysFont("Courier New", 16)

max_bounces = 10
num_bounces = 0
Cacodemon_sprite = pygame.image.load("Cacodemon_sprite64.png")
cacox = 400
cacoy = 300
radius = 0
#radiusx = 32
#radiusy = 36

caco_horizontal_speed = 0.5
caco_vertical_speed = 0.5

while num_bounces < max_bounces:
    
    
    
    cacox += caco_horizontal_speed
    cacoy += caco_vertical_speed
    
    if cacoy - radius <= 0:
        #print("passing the top edge!!!")
        #print(f"starting bounce # {num_bounces}")
        num_bounces += 1
        caco_vertical_speed *= -1
    if cacoy - radius >= win_height:
        num_bounces += 1
        caco_vertical_speed *= -1
    if cacox - radius <= 0:
        #print("passing the top edge!!!")
        #print(f"starting bounce # {num_bounces}")
        num_bounces += 1
        caco_horizontal_speed *= -1
    if cacox - radius >= win_width:
        num_bounces += 1
        caco_horizontal_speed *= -1
    
    win.fill((64,64,64))
    
    text = f"Current Bounce: {num_bounces} / {max_bounces}"
    text_surf = font_obj.render(text, False, (0,255,0), (0,0,0))
    win.blit(text_surf, (0,0))
    
    win.blit(Cacodemon_sprite, (cacox,cacoy))
    
    pygame.display.flip()
    time.sleep(0.001)


pygame.quit