#Thomas King Notes for Module12
#each time the user click the mouse then they spawn a new circle

#pygame setup
import pygame
import random

pygame.display.init()
pygame.font.init()
win_width = 800
win_height = 600
win = pygame.display.set_mode((win_width, win_height))
clock = pygame.time.Clock()
font_obj = pygame.font.SysFont("Courier New", 18)
done = False

#parallel lists
circle_x_lists = []
circle_y_lists = []
circle_radius_list = []
circle_speed_list = []
#red = random.randint(0,255) \ green = random.randint(0,255) \ blue = random.randint(0,255) \ circle_color = (red, green, blue)
#circle_color = (random.randint(0, 255), random.randint(0,255), random.randint(0,255))
#Game Loop
while not done:
    #updates
    delta_time = clock.tick() / 1000
    #move circles in a for lop
    for j in range(len(circle_x_lists) - 1, -1, -1):
        #j is an index into all the lists (python will do the work)
        circle_x_lists[j] += circle_speed_list[j] * delta_time
        #destroy any that go off-screen
        #if you destroy the first or the second item the other elements collapse to take its place
        if circle_x_lists[j] < -circle_radius_list[j] or \
            circle_x_lists[j] > win_width + circle_radius_list[j]:
            del circle_x_lists[j]
            del circle_y_lists[j]
            del circle_radius_list[j]
            del circle_speed_list[j]
    #input
    event = pygame.event.poll()
    if event.type == pygame.QUIT:
        done = True
    elif event.type == pygame.KEYDOWN:
        if event.key == pygame.K_ESCAPE:
            done = True
    elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
        #spawn new circle
        circle_x_lists.append(event.pos[0])
        circle_y_lists.append(event.pos[1])
        circle_radius_list.append(random.randint(5,25))
        if random.choice(("heads", "tails")) == "heads":
            #move left, random.randint(-20,-200) also works
            circle_speed_list.append(-random.randint(20,200))
        else:
            circle_speed_list.append(random.randint(20,200))
    #drawing
    win.fill((0,0,0))
    #with parallel list we have to access by index
    i = 0
    while i < len(circle_x_lists):
        #i is the index into all the lists
        pygame.draw.circle(win, (200,50,0), (circle_x_lists[i], circle_y_lists[i]), circle_radius_list[i])
        i += 1

    text_surf = font_obj.render("# Circles: " + str(len(circle_speed_list)), False, (0,255,0))
    win.blit(text_surf, (0, 0))
    pygame.display.flip()

pygame.quit()

"""
all_lists = []
all_lists.append([5,  7, 3])
all_lists.append([14, 8, 19])
all_lists.append([23, 4, 0])
print(all_lists[0][0])
print(all_lists[2][2])
print(all_lists[1][-1])
#we can make a list of enemies this way and each sublist store the x, y, radius, speed
"""