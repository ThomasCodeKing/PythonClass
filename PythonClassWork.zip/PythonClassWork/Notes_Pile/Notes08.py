#pygame setups
import pygame

pygame.display.init()
win_width = 800
win_height = 600
win = pygame.display.set_mode((win_width, win_height))

#variables in the game loop
game_over = False
rectx = 400
recty = 300
rect_size = 10
#Game Loop
while not game_over:
    #update
    
    #input
    #do this first ... we only need to sace the event object if we plan to do some event handling 
    current_event = pygame.event.poll()
    
    print(f"Current event type is {current_event.type}")
    if current_event.type == pygame.QUIT:
        game_over = True
    elif current_event.type == pygame.KEYDOWN:
        print(f"The {current_event.type} key was pressed")
        if current_event.key == pygame.k_LEFT:
        #left arrow key
            print("\t(the left arrow)")
            rectx -= 10
            pass current_event.key == pygame.k_LEFT:
        elif current_event.key == pygame.k_RIGHT:
        #right arrow key
            print("\t(the left arrow)")
            rectx += 10
    elif current_event.type == pygame.MOUSEMOTION:
        #method 1
        #mousex, mousey = current_event.pos
        #method 2
        mousex = current_event.pos[0]
        moussy = current_event.pos[1]
        print(f"Mouse at ({mousex}, {mousey})")
    elif current_event.type == pygame.MOUSEBUTTONDOWN:
        #1 = left
        #2 middle click
        #3right click
        #4 scroll wheel up
        #5 scroll wheel down
        #(other event buttons)
        
        print(f"The{current_event.button} button was pressed")
    #drawing
    #erase
    win.fill((32,50,32))
    #draw
    pygame.draw.rect(win, (0,255,0), (rectx - rect_size / 2, recty - rect_size / 2, rect_size, rect_size))
    pygame.display.flip()


#shutdown
pygame.quit()