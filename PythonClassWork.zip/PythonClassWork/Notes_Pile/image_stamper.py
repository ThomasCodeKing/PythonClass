import pygame

# Pygame setup
pygame.display.init()
pygame.font.init()
win_width = 800
win_height = 600
win = pygame.display.set_mode((win_width, win_height))
done = False

# Load the image assets into a tuple (there ARE better ways to do this)
stamp_images = (pygame.image.load("Round (outline)/elephant.png"),
                pygame.image.load("Round (outline)/giraffe.png"),
                pygame.image.load("Round (outline)/hippo.png"),
                pygame.image.load("Round (outline)/monkey.png"),
                pygame.image.load("Round (outline)/panda.png"),
                pygame.image.load("Round (outline)/parrot.png")
                )
cur_stamp_img = 0

# GAME LOOP
while not done:
    # UPDATE

    # INPUT
    event = pygame.event.poll()
    # ... do some event-handling
    if event.type == pygame.QUIT:
        done = True
    elif event.type == pygame.MOUSEBUTTONDOWN:
        if event.button == 4:
            # Scroll wheel up -- decrease our cur_stamp_img value.  Make
            # sure it doesn't go below 0.
            cur_stamp_img -= 1
            if cur_stamp_img < 0:
                cur_stamp_img = 0
        elif event.button == 5:
            # Scroll wheel down -- increase our cur_stamp_img value.  Make
            # sure it doesn't go above len(stamp_images) - 1
            cur_stamp_img += 1
            if cur_stamp_img >= len(stamp_images):
                cur_stamp_img = len(stamp_images) - 1
    # ... do some device-polling
    keys = pygame.key.get_pressed()  # Returns a tuple of booleans, one for
                                     #  each key
    if keys[pygame.K_ESCAPE]:
        # pygame.K_ESCAPE is an integer holding 27.  We're using
        # INDEXING here to look at the 28th to see if it's True.
        done = True
    # ......get the mouse position
    mouse_x, mouse_y = pygame.mouse.get_pos()   # using TUPLE-UNPACKING
    # or
    #mouse_pos = pygame.mouse.get_pos()
    #mouse_x = mouse_pos[0]
    #mouse_y = mouse_pos[1]

    # DRAWING
    cur_img = stamp_images[cur_stamp_img]
    cur_img_w = cur_img.get_width()
    cur_img_h = cur_img.get_height()
    win.blit(cur_img, (mouse_x - cur_img_w / 2, mouse_y - cur_img_h / 2))
    pygame.display.flip()

# Pygame shutdown
pygame.quit()
