#Basic Sprites and lab08 notes
import pygame
import random
import time

pygame.display.init()
pygame.font.init()      #allows us to use font stuff
window_width = random.randint(64,800)
window_height = random.randint(75,800)

window = pygame.display.set_mode((window_width, window_height)) 
#load assets first
demon = pygame.image.load("Cacodemon_sprite64.png")
demon_width = demon.get_width()
demon_height = demon.get_height()
print(f"The Demon is {demon_width}x{demon_height}")

window.blit(demon, (0,0))
window.blit(demon, (100,200))
window.blit(demon, (window_width - demon_width, 0)) #top right
window.blit(demon, (window_width / 2 - demon_width / 2,window_height / 2 - demon_height/2)) 
pygame.draw.circle(window, (0,255,0), (window_width / 2, window_height / 2),3) #middle image
window.blit(demon, (0,150), (10, 25, 23, 34)) #part of a face
                            #x,y,height,width,
#font notes
"""
pygame.font.init()
font_obj = pygame.font.Font("fonts\\Times-NewRoman_wght.ttf", 24)   #makes font object
temp_surface = font_obj.render("The Cacodemon Approaches!@*#&@!", True, (255,0,0))  #Renders the font text
window.blit(temp_surface, (window_width / 2, window_height / 2 - 50))   #blits the text to the display: window window.blit(surface, (xcord, ycord))

"""
pygame.display.flip()
time.sleep(3)
pygame.quit()

#google fonts and dafont.com for font websites