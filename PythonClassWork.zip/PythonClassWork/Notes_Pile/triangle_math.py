#show how to do some math for lab12
#make a player that moves with WASD and make an aiming reticle
import pygame
import random
#pygame setup
pygame.display.init()
win_width = 800
win_height = 600
win = pygame.display.set_mode((win_width, win_height))
clock = pygame.time.Clock()
#store all the player data
player = {"x": 400, "y": 300, "radius": 75, "speed": 100}

bullet_x_lists = []
bullet_y_lists = []
bullet_radius_list = []
bullet_speed_list = []
bullet_list = []

#game loop
while True:
    #update

    delta_time = clock.tick() / 1000.0
    #input
    pygame.event.pump()
    event = pygame.event.poll()
    keys = pygame.key.get_pressed()
    click = pygame.mouse.get_pressed()
    mpos = pygame.mouse.get_pos()

    if keys[pygame.K_ESCAPE]:
        #a break statement terminates the loop
        #stops the current iteration of the loop but goes on with the next iteration of the loop
        break
    #player movement. Use this code in lab12.py
    player_vel_x = 0        #player velocity vector
    player_vel_y = 0        #horizontal speed and vertical speed is all it is
    if keys[pygame.K_a]:
        player_vel_x -= 1
    if keys[pygame.K_d]:
        player_vel_x += 1
    if keys[pygame.K_w]:
        player_vel_y -= 1
    if keys[pygame.K_s]:
        player_vel_y += 1

#player velocity
    if abs(player_vel_x) > 0 or abs(player_vel_y) > 0:
        cur_speed = (player_vel_x ** 2 + player_vel_y ** 2) ** 0.5
        player_vel_x *= (player["speed"] * delta_time / cur_speed)
        player_vel_y *= (player["speed"] * delta_time / cur_speed)
        #apply offsets to the player position
        player["x"] += player_vel_x
        player["y"] += player_vel_y
    #create 3 points in the player mouse triangle
    pmA = mpos
    pmB = (player["x"], player["y"])
    pmC = (player["x"], mpos[1])
    #or ptC = (mpos[0], player["y"]
    #create a vector of the two triangles
    mouse_offset_x = mpos[0] - player["x"]
    mouse_offset_y = mpos[1] - player["y"]
    #hypotenuse length tells us how many pixels the mouse is from the player center
    mouse_hypotenuse = (mouse_offset_x ** 2 + mouse_offset_y ** 2) ** 0.5
    normalized_offset_x = mouse_offset_x / mouse_hypotenuse
    normalized_offset_y = mouse_offset_y / mouse_hypotenuse
    #make a vector length we want by multiplying adjacent and
    # opposite sides by some values(circle radius)
    aim_offset_x = normalized_offset_x * player["radius"]
    aim_offset_y = normalized_offset_y * player["radius"]
    #compute an aiming reticle on the edge of the circle
    aim_x = player["x"] + aim_offset_x
    aim_y = player["y"] + aim_offset_y
    #make a point 55 pixels from that aiming point
    aim_x2 = aim_x + normalized_offset_x * 55
    aim_y2 = aim_y + normalized_offset_y * 55
    #make bullet travel
    #drawing

    win.fill((10, 10, 10))
    pygame.draw.rect(win, (255, 0, 0), (player["x"] - 5, player["y"] - 5, 10, 10))
    pygame.draw.circle(win, (255,255,255), (player["x"], player["y"]), player["radius"], 1)
    #the right triangle
    pygame.draw.polygon(win, (0, 255, 0), (pmA, pmB, pmC), 1)
    #the aiming reticle
    pygame.draw.circle(win, (255, 255, 255), (aim_x, aim_y), 8) #This is where I want the bullet to spawn
    pygame.draw.circle(win, (255, 0, 255), (aim_x2, aim_y2), 4)
    pygame.draw.circle(win, (255, 0, 0), (mpos[0], mpos[1]), 2)
    #pygame.draw.circle(win, (55, 55, 0), (bullet_v_y, bullet_v_y), 6)      #this is my bullet
    pygame.display.flip()


#close program
pygame.quit()
