#basic functions in py
#a function definition( a new tool for the user to use)
def say_something1():
    """this is an option DOCSTRING. Put any
    notes to  the user in here (most IDE's
    will display this)"""
    print("Hello Monkai!")
def draw_box(num_rows, num_cols, fill_char= "8", outer_char = "^"):
    print(outer_char * num_cols)
    for i in range(num_rows - 2):
        print(outer_char + (fill_char * (num_cols - 2)) + outer_char)
    print(outer_char * num_cols)

#this code is outside the function def. and is considered the main program.
#program

say_something1()
say_something1()

#adding parameters to a function makes it more general
#parameters only exist in their function (their SCOPE is the function)
def say_something2(message, num_times):
    #caution: try to only look at our parameters and desired behaviors
    #only work here (encapsulation). If you are looking at variables
    #in the main program, you're violating encapsulation.
    #caution PT2: Don;t assign values to the parameters
    print("Bullet Shoot Shoot Bullet Bullet:")
    for i in range(num_times):
        print("\t", message)
    print("... no more bullets, no more bullets")

#arguments for each parameter
say_something2("Bang", 3)

x = "Uh oh Stinky!"
say_something2(x, 4)

#the user of this function doesn't need to worry about the details.
#This is called abstraction.
draw_box(4, 6, "'", "@")
draw_box(10, 10, "0", "-")
draw_box(4, 5, " ")                             #uses default value for 1 of the items
draw_box(3, 3, outer_char="+")                  #skips the order
draw_box(5, 5, outer_char=">", fill_char="+")   #flips the order
draw_box(4, 4)                                  #uses the default value

def adder(a, b):
    #""" enter will show the parameters for the def
    """
    This function adds two parameter values and returns the result
    :param a:
    :param b:
    :return:
    """
    c = a + b   #C is a local variable and only exists in this def

#CTRL Q will make the parameters show when hovering the adder()
adder(4, 5)
print(adder(4, 5))      #9
result = adder(4, 5)
print("the result is", result)


def distance(x1, y1, x2, y2):
    """
    Computes the distance between the two given points in 2d
    :param x1:  the x-coordinate of the first point
    :param y1:  the x-coordinate of the first point
    :param x2:  the x-coordinate of the second point
    :param y2:  the x-coordinate of the second point
    :return: the distance (in the same units as x1, y1, x2, y2)
    """
    a = x1 - x2
    b = y1 - y2
    c = (a ** 2 + b ** 2) ** 0.5
    return c

player_x = 400
player_y = 300
enemy_x = 260
enemy_y = 150
pe_dist = distance(player_x, player_y, enemy_x, enemy_y)
print(pe_dist)
