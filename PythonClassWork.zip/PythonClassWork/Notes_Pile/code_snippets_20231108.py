# The bullets are stored in these 4 parallel lists
bullet_x_list = []
bullet_y_list = []
bullet_hspeed_list = []
bullet_vspeed_list = []
# The enemies are stored in a list of dictionaries (keys of "x", "y", "type")
enemy_list = []

# This was some of the data in my player dictionary
player = {
 "x": 400
 "y": 300
 "invul_timer": 0.0,     # time in seconds till the player takes damage again
 "flicker_timer": 0.0,   # Every 0.1, flip invul_draw 
 "invul_draw": True
 }


# In the game loop
	# UPDATE
	# ... the way I did the i-frames
	if player["invul_timer"] > 0:
		player["invul_timer"] -= delta_time
		player["flicker_timer"] -= delta_time
		if player["flicker_timer"] <= 0:
			# Change draw state
			player["invul_draw"] = not player["invul_draw"]
			player["flicker_timer"] += 0.1
	# ... look for hits between player bullets and enemies:
	#    if we had one bullet and one enemy: one distance check
	#    if we have 5 bullets and one enemy: 5 distance checks
	#    if we have 1 bullet and 6 enemies: 6 distance checks
	#    if we have 3 bullets and 4 enemies: 12 distance checks (check each
	#        bullet against EVERY enemy)
	# We MUST do a while loop or an index-based for loop for the bullets (we
	#    can't do a value-based for loop since we have multiple lists)
	for i in range(len(bullet_x_list)-1, -1, -1):
		# Any code we write here can use i to index the 4 bullet list
		# We need to check this current bullet i with ALL the enemies
		for cur_enemy in enemy_list:
			# Here, I need to check bullet i again cur_enemy to see if there
			# is a hit
			dist = ???   # hint: bullet_x_list[i], and similar and 
			             #  cur_enemy["x"] and similar. 
			if dist < bullet_radius + enemy_radius:
				# They touch.  We want to remove the current enemy and 
				#   bullet.
				del bullet_x_list[i]
				del bullet_y_list[i]
				del bullet_hspeed_list[i]
				del bullet_vspeed_list[i]
				enemy_list.remove(cur_enemy)
				# Tricky potential bug: we just destroyed a bullet and an 
				# enemy.  We DON'T want to do anything else with the 
				# dead bullet or enemy.
				break
	# ... make all the bullets move
	for i in range(len(bullet_x_list)):
		bullet_x_list[i] += bullet_hspeed_list[i] * delta_time
		bullet_y_list[i] += bullet_vspeed_list[i] * delta_time
				
	# INPUT
	event = pygame.event.poll()
	if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
		# The user just left-clicked -- spawn a new bullet
		mouse_x, mouse_y = event.pos
		# Calculate the mouse offset as a vector, normalize it, then make
		# a point (spawn_x, spawn_y) right on the edge of the bounding circle
		# Now, use the normalized vector to make another vector of hypotenuse
		#  length = bullet_speed, the two parts are bullet_hspeed, bullet_vspeed
		bullet_x_list.append(spawn_x)
		bullet_y_list.append(spawn_y)
		bullet_hspeed_list.append(bullet_hspeed)
		bullet_vspeed_list.append(bullet_vspeed)
	