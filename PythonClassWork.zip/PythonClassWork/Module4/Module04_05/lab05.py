#Thomas King, ETGG1801-01, lab05
#compute inner diameter: inner diameter = diameter - 2  * depth of crust

diameter = input("Enter the diameter of the sphere (in m): ")
density = input("Enter the density of the sphere (in kg/cubic-m): ")
depth = input("Enter the depth of the crust layer: ")
#insert string = int(insert string)     permenantly changes to integer  
diameter = int(diameter)
density = int(density)
depth = int(depth)
#formula for volume: volume = 4/3 (Pie)radius ** 3
#formula for mass of an object is: mass = volume * density
radius = diameter / 2
volume = 4/3 * 3.14 * radius ** 3
mass = volume * density
#setting mass to round will set the number of decimal places and round up to the set amount
rmass = round(mass, 2)
#print(radius)
#print(rmass)
print("The mass of the crust is", rmass)
#chp = current hp
#mhp = max hp
chp = input("\nEnter the current hp: ")
mhp = input("Enter the maximum hp: ")
#change to int
chp = int(chp)
mhp = int(mhp)
#dhp = difference hp
dhp = chp / mhp 
#logic to make health bar print nice and good
health_bar = 40 * dhp
health_bar = int(health_bar)
health_space = 40 - health_bar 
health_space = int(health_space)
print("/","-"*40,"\\")
print("|","+"*health_bar," "*health_space,"|")
print("\\","-"*40,"/")
input("Press Enter to continue")