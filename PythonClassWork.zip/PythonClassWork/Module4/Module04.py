#when finding file I can type: cd PythonClassWork\Module4
#then to run file type "python" then the file name to run; Example: python Module04.py 
#Another way is to highlight file location and then type cmd

x = 3.7
x = 4.5
x = "asdf"

s = "asdf"
s = 'asdf'
s = """asdf"""
s = '''asdf'''

print("I said 'Hello' .")
print ("""I said "Hello".""")
print("""first line here
scond line here""")

#examples of using excape sequences
#   \n Newline
#   \t Tab
#   \" Print a quote (don't end a string)
#   \'Print a single-quote
#   \\ Print a single backslash
print("aaa\nbbb")
print("ccc\tddd")
print("eee\\fff")
print("c:\temp\link.png")
print("c:\\temp\\link.png")

face_color = (250, 150, 0)  #tuple
inventory = ("sword", "shield", "potion")   #list
#sounds = ("pew": pygame.mixer.Sound("kaboom.wav"),
#"death": pygame.mixer.Sound("groan.og"))

game_over = False   #Boolean
player_name = None  #Boolean

print(" Hello, Monkai" * 3)

print(" +---+\n/\"\"\"\"\"\\\n|\"'''\"|\n\\\"\"\"\"\"/\n +---+")