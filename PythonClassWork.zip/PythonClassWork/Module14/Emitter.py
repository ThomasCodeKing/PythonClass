#Thomas King, ETGG1801-01, lab14
#Emitter will be used to spawn instances of Particle to the screen
import pygame
import Particle

class emitter:
    def __init__(self, ):
        pass
