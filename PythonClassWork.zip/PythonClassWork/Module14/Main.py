#Thomas King, ETGG1801-01, lab14
#Main file for particle class and emitter class
import pygame

pygame.display.init()
pygame.font.init()

win = pygame.display.set_mode((800, 600))
clock = pygame.time.Clock()
font = pygame.font.SysFont("Courier New", 16)

done = False

while not done:
    #update
    dt = clock.tick() / 1000
    #input
    evt = pygame.event.poll()
    if evt.type == pygame.QUIT:
        done = True
    if evt.type == pygame.KEYDOWN and evt.key == pygame.K_ESCAPE:
        done = True

    #drawing
    win.fill((0, 0, 0))
    pygame.display.flip()

pygame.quit()
