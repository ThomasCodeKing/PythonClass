#Thomas King, ETGG1801-01, lab14
#particle.py contains the class particle that is used in the emitter and represents a single particle.
import pygame
import random


# I had several days of help from SI's when writing this lab.
class particle:
    """A pixel ember the pops up in the air before gravity pulls it down"""
    def __init__(self, gradient_img, x, y, velocity_x, velocity_y, lifetime, particle_img, bounding_radius):
        """The meat & potatoes of the particle: What the particle is"""
        self.mGradientImage = gradient_img
        self.mPosition = [x, y]
        self.mVelocity = [velocity_x, velocity_y]
        self.mLifetime = lifetime
        self.mMaxLifetime = 1000
        self.mDrawImage = particle_img
        self.mBoundingRadius = bounding_radius
        self.mOrientation = 10
        x = random.randint(0, 1)
        if x == 1:
            x = -1
            self.mRotationSpeed = ((random.randint(10, 180)) / 100) * x  # px/s pixel per second?
        else:
            self.mRotationSpeed = (random.randint(10, 180)) / 100  # px/s pixel per second?

    def update(self, delta_time,simulation_boundaries, gravity_acceleration=0.0):
        """velocity, orientation, and position of the particle"""
        #Velocity and the Position of x & y
        self.mGravity_Acceleration = gravity_acceleration
        self.mVelocity[1] += gravity_acceleration * delta_time
        self.mPosition[1] += self.mVelocity[1] * delta_time
        self.mPosition[0] += self.mVelocity[0] * delta_time
        #orientation modified by the rotation
        self.mOrientation += self.mRotationSpeed * delta_time
        self.mDrawImage = pygame.transform.rotate(self.mDrawImage, self.mOrientation)
        #lifetime
        self.mLifetime += 5
        #particle death on -y
        #return self.mPosition[1] > simulation_boundaries[3] + self.mBoundingRadius
        #^^This is not working the way I thought It would and errors ^^
    #def sprite_info(self, color, add_alph):
        #pass       ++++used this in trying to figure out alphas++++
    def draw(self, surf):
        """Getting information to draw the particle onto the screen"""
        hp_percent = self.mLifetime / self.mMaxLifetime
        temp_hp = 512 * hp_percent
        color = surf.get_at(int(512 - temp_hp),0)
        #^^^All attempts I made to get this to work did not succeed^^^^^
        #I followed the error instructions, but was not able to find a solution.
        color[3] = 255 - (hp_percent * 255)
        self.mDrawImage.set_alpha(color[3])
        self.mDrawImage.fill(color)
        #Image
        surf.blit(self.mDrawImage, (self.mPosition[0] - self.mDrawImage.get_width() / 2,self.mPosition[1] - self.mDrawImage.get_height() / 2))

    def __str__(self):
        """Text: IDK what should be here, but I put x, y, velocity_y, orientation, lifetime"""
        return f"Particle [({self.mPosition[0]}, {self.mPosition[1]}, {self.mVelocity[1]}) ori={round(self.mOrientation, 1)} life={round(self.mLifetime, 1)}/1000.0  ]"

#testing particle
if __name__ == "__main__":
    pygame.display.init()
    pygame.font.init()

    win = pygame.display.set_mode((800, 600))
    clock = pygame.time.Clock()
    font = pygame.font.SysFont("Courier New", 16)
    done = False

    P = particle(pygame.image.load("images\\particle.png"),400,10,1,5,10,pygame.image.load("images\\muzzle_05.png"),20)
    #^^^^^^^I typed this out several times; the same that is being shown now and other ways that made
    #^^^^^^^more sense to me,but it kept being shown as error.
    print("P = ", P)
    P_dead = False
    while not done:
        dt = clock.tick() / 1000
        if not P_dead:
            P_dead = P.update(dt, 600)
        event = pygame.event.poll()
        if event.type == pygame.QUIT:
            done = True
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            done = True

        #Draw
        win.fill((0,0,0))
        if not P_dead:
            P.draw(win)
        pygame.display.flip()

pygame.display.flip()
